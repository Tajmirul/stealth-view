import"./_virtual_wxt-html-plugins-DPbbfBKe.js";import{b as r}from"./browser-C4Hj5S8A.js";r.tabs.create({url:r.runtime.getURL("/player.html"),active:!0});
