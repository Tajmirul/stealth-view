import { defineWebExtConfig } from "wxt";

export default defineWebExtConfig({
  disabled: false,
  startUrls: ["https://www.youtube.com/results?search_query=web+extensions"],
});
