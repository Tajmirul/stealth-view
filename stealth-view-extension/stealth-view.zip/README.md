# StealthView

Youtube is recently blocking ad-blockers. So we've developed an work-around. If auto skip does not work, add any video to StealthView playlist and watch them outside of youtube. This way youtube won't be able to show ads.

## How to build the extension

```bash
npm install -g pnpm
pnpm install

pnpm build // for cromium based browsers
pnpm build:firefox // for firefox
```

Then import the generated files from `.output` folder.

#### Versions

```
node: >= v18.20.6
pnpm: >= 10.4.1
```

## How to disable it

To change the settings, right-click the extension icon -> options. You'll see the available settings options.
